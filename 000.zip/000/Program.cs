﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;

namespace KuleSavunmaOyunu
{
   
    static class Program
    {
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new OyunFormu());
        }
    }

   
    public interface ISaldirabilir
    {
        void Saldir(List<Dusman> dusmanlar, Graphics g);
    }

    public interface IYukseltilebilir
    {
        void Yukselt();
    }

  
    public abstract class Kule : ISaldirabilir, IYukseltilebilir
    {
        private int _hasar;
        private int _menzil;
        private int _fiyat;
        private float _saldiriHizi;
        protected DateTime _sonSaldiriZamani;

        public int Hasar { get => _hasar; set => _hasar = value; }
        public int Menzil { get => _menzil; set => _menzil = value; }
        public int Fiyat { get => _fiyat; set => _fiyat = value; }
        public float SaldiriHizi { get => _saldiriHizi; set => _saldiriHizi = value; }

        public Point Konum { get; set; }
        public Color Renk { get; set; }
        public string Ad { get; set; }

        public Kule(string ad, int hasar, int menzil, int fiyat, float saldiriHizi, Color renk)
        {
            Ad = ad;
            Hasar = hasar;
            Menzil = menzil;
            Fiyat = fiyat;
            SaldiriHizi = saldiriHizi;
            Renk = renk;
            _sonSaldiriZamani = DateTime.Now;
        }

        public abstract void Saldir(List<Dusman> dusmanlar, Graphics g);

        public virtual void Yukselt()
        {
            Hasar += 5;
            Fiyat += 50;
        }

        protected bool SaldirabilirMi()
        {
            return (DateTime.Now - _sonSaldiriZamani).TotalSeconds >= SaldiriHizi;
        }

        protected double MesafeHesapla(Point p1, PointF p2)
        {
            return Math.Sqrt(Math.Pow(p1.X - p2.X, 2) + Math.Pow(p1.Y - p2.Y, 2));
        }
    }

  
    
    public class OkKulesi : Kule
    {
        public OkKulesi(Point konum) : base("Ok Kulesi", 15, 150, 100, 1.0f, Color.Blue)
        {
            Konum = konum;
        }

        public override void Saldir(List<Dusman> dusmanlar, Graphics g)
        {
            if (!SaldirabilirMi()) return;

            var hedef = dusmanlar
                .Where(d => MesafeHesapla(Konum, d.Konum) <= Menzil)
                .OrderBy(d => MesafeHesapla(Konum, d.Konum))
                .FirstOrDefault();

            if (hedef != null)
            {
                hedef.HasarAl(Hasar);
                _sonSaldiriZamani = DateTime.Now;
                g.DrawLine(Pens.Blue, Konum, Point.Round(hedef.Konum));
            }
        }
    }

    
    public class TopKulesi : Kule
    {
        public TopKulesi(Point konum) : base("Top Kulesi", 50, 120, 250, 3.0f, Color.Red)
        {
            Konum = konum;
        }

        public override void Saldir(List<Dusman> dusmanlar, Graphics g)
        {
            if (!SaldirabilirMi()) return;

            var hedefler = dusmanlar
                .Where(d => MesafeHesapla(Konum, d.Konum) <= Menzil)
                .ToList();

            if (hedefler.Count > 0)
            {
                g.DrawEllipse(Pens.Red, Konum.X - Menzil, Konum.Y - Menzil, Menzil * 2, Menzil * 2);
                foreach (var h in hedefler)
                {
                    h.HasarAl(Hasar);
                    g.DrawLine(Pens.Red, Konum, Point.Round(h.Konum));
                }
                _sonSaldiriZamani = DateTime.Now;
            }
        }
    }

  
    public class BuyuKulesi : Kule
    {
        public BuyuKulesi(Point konum) : base("Büyü Kulesi", 25, 130, 200, 1.5f, Color.Purple)
        {
            Konum = konum;
        }

        public override void Saldir(List<Dusman> dusmanlar, Graphics g)
        {
            if (!SaldirabilirMi()) return;

            var hedefler = dusmanlar
                .Where(d => MesafeHesapla(Konum, d.Konum) <= Menzil)
                .OrderBy(d => MesafeHesapla(Konum, d.Konum))
                .Take(5)
                .ToList();

            if (hedefler.Count > 0)
            {
                foreach (var h in hedefler)
                {
                    h.HasarAl(Hasar);
                    g.DrawLine(Pens.Purple, Konum, Point.Round(h.Konum));
                }
                _sonSaldiriZamani = DateTime.Now;
            }
        }
    }

   
    public class Dusman
    {
        public PointF Konum { get; set; }
        public int Can { get; private set; }
        public int MaxCan { get; private set; }
        public float Hiz { get; set; }
        public int Odul { get; set; }
        private int _hedefNoktaIndex = 0;
        public bool OlduMu => Can <= 0;
        public bool HedefeUlastiMi { get; private set; } = false;

        public Dusman(int can, float hiz, Point baslangic)
        {
            Can = can;
            MaxCan = can;
            Hiz = hiz;
            Konum = baslangic;
            Odul = 10;
        }

        public void HareketEt(List<Point> yol)
        {
            if (_hedefNoktaIndex >= yol.Count)
            {
                HedefeUlastiMi = true;
                return;
            }

            Point hedef = yol[_hedefNoktaIndex];
            float dx = hedef.X - Konum.X;
            float dy = hedef.Y - Konum.Y;
            float mesafe = (float)Math.Sqrt(dx * dx + dy * dy);

            if (mesafe < Hiz)
            {
                Konum = hedef;
                _hedefNoktaIndex++;
            }
            else
            {
                Konum = new PointF(Konum.X + (dx / mesafe) * Hiz, Konum.Y + (dy / mesafe) * Hiz);
            }
        }

        public void HasarAl(int hasar)
        {
            Can -= hasar;
        }
    }

   
    public class OyunFormu : Form
    {
        
        private List<Dusman> _dusmanlar = new List<Dusman>();
        private List<Kule> _kuleler = new List<Kule>();
        private List<Point> _yol = new List<Point>();

        private int _altin = 600;
        private int _can = 20;
        private int _dalga = 1;
        private int _skor = 0;

        
        private bool _dalgaAktif = false;
        private int _spawnlanacakDusmanSayisi = 0;
        private int _spawnlananDusmanSayisi = 0;

        private string _seciliKuleTipi = "Ok";
        private Timer _oyunDongusu;
        private Timer _dusmanDogurmaZamanlayici;

        
        private Panel _ustPanel;
        private Panel _altPanel;
        private Label _lblBilgi;
        private Button _btnDalgaBaslat;

        public OyunFormu()
        {
            this.Size = new Size(1000, 750);
            this.Text = "Kule Savunma - NTP Proje";
            this.DoubleBuffered = true;
            this.BackColor = Color.FromArgb(30, 30, 30);

            YoluOlustur();
            ArayuzuOlustur();
            ZamanlayicilariBaslat();

            this.Paint += OyunFormu_Paint;
            this.MouseClick += OyunFormu_MouseClick;
        }

        private void YoluOlustur()
        {
            _yol.Add(new Point(0, 200));
            _yol.Add(new Point(200, 200));
            _yol.Add(new Point(200, 400));
            _yol.Add(new Point(500, 400));
            _yol.Add(new Point(500, 150));
            _yol.Add(new Point(800, 150));
            _yol.Add(new Point(800, 300));
            _yol.Add(new Point(1000, 300));
        }

        private void ArayuzuOlustur()
        {
            _ustPanel = new Panel { Dock = DockStyle.Top, Height = 60, BackColor = Color.FromArgb(50, 50, 50) };

            _lblBilgi = new Label
            {
                Text = "",
                ForeColor = Color.Gold,
                Font = new Font("Arial", 12, FontStyle.Bold),
                AutoSize = true,
                Location = new Point(20, 18)
            };

            _btnDalgaBaslat = new Button
            {
                Text = "DALGA BAŞLAT",
                BackColor = Color.Green,
                ForeColor = Color.White,
                Font = new Font("Arial", 10, FontStyle.Bold),
                Location = new Point(800, 10),
                Size = new Size(150, 40),
                FlatStyle = FlatStyle.Flat
            };
            _btnDalgaBaslat.Click += BtnDalgaBaslat_Click;

            _ustPanel.Controls.Add(_lblBilgi);
            _ustPanel.Controls.Add(_btnDalgaBaslat);
            this.Controls.Add(_ustPanel);

            
            _altPanel = new Panel { Dock = DockStyle.Bottom, Height = 80, BackColor = Color.FromArgb(50, 50, 50) };

            Button btnOk = ButonOlustur("Ok Kulesi (100 Altın)", 20, Color.Blue, "Ok");
            Button btnTop = ButonOlustur("Top Kulesi (250 Altın)", 200, Color.Red, "Top");
            Button btnBuyu = ButonOlustur("Büyü Kulesi (200 Altın)", 380, Color.Purple, "Buyu");

            _altPanel.Controls.Add(btnOk);
            _altPanel.Controls.Add(btnTop);
            _altPanel.Controls.Add(btnBuyu);
            this.Controls.Add(_altPanel);
        }

        private Button ButonOlustur(string text, int x, Color renk, string tag)
        {
            Button btn = new Button();
            btn.Text = text;
            btn.Location = new Point(x, 15);
            btn.Size = new Size(160, 50);
            btn.BackColor = renk;
            btn.ForeColor = Color.White;
            btn.FlatStyle = FlatStyle.Flat;
            btn.Tag = tag;
            btn.Click += (s, e) => { _seciliKuleTipi = tag; };
            return btn;
        }

        private void ZamanlayicilariBaslat()
        {
            _oyunDongusu = new Timer();
            _oyunDongusu.Interval = 16;
            _oyunDongusu.Tick += OyunDongusu_Tick;
            _oyunDongusu.Start();

            _dusmanDogurmaZamanlayici = new Timer();
            _dusmanDogurmaZamanlayici.Interval = 1500;
            _dusmanDogurmaZamanlayici.Tick += DusmanDogur_Tick;
            _dusmanDogurmaZamanlayici.Start();
        }

        private void BtnDalgaBaslat_Click(object sender, EventArgs e)
        {
            if (!_dalgaAktif)
            {
                
                _spawnlanacakDusmanSayisi = 5 + (_dalga - 1) * 2;
                _spawnlananDusmanSayisi = 0;
                _dalgaAktif = true;
                _btnDalgaBaslat.Enabled = false; 
                _btnDalgaBaslat.Text = "Dalga Sürüyor...";
                _btnDalgaBaslat.BackColor = Color.Gray;
            }
        }

        private void DusmanDogur_Tick(object sender, EventArgs e)
        {
           
            if (_dalgaAktif && _spawnlananDusmanSayisi < _spawnlanacakDusmanSayisi)
            {
                if (_can > 0)
                {
                    
                    int can = 30 + (_dalga * 15);
                    float hiz = 3.0f + (_dalga / 3.0f);

                    _dusmanlar.Add(new Dusman(can, hiz, _yol[0]));
                    _spawnlananDusmanSayisi++;
                }
            }
        }

        private void OyunDongusu_Tick(object sender, EventArgs e)
        {
            if (_can <= 0)
            {
                OyunBitti();
                return;
            }

            
            for (int i = _dusmanlar.Count - 1; i >= 0; i--)
            {
                var d = _dusmanlar[i];
                d.HareketEt(_yol);

                if (d.HedefeUlastiMi)
                {
                    _can--;
                    _dusmanlar.RemoveAt(i);
                }
                else if (d.OlduMu)
                {
                    _altin += d.Odul;
                    _skor += 10;
                    _dusmanlar.RemoveAt(i);
                }
            }

            
            if (_dalgaAktif && _spawnlananDusmanSayisi >= _spawnlanacakDusmanSayisi && _dusmanlar.Count == 0)
            {
                _dalgaAktif = false;
                _dalga++; 
                _btnDalgaBaslat.Enabled = true;
                _btnDalgaBaslat.Text = "DALGA BAŞLAT";
                _btnDalgaBaslat.BackColor = Color.Green;
            }

            _lblBilgi.Text = $"Altın: {_altin}  |  Can: {_can}  |  Dalga: {_dalga}  |  Skor: {_skor}  |  Seçili: {_seciliKuleTipi}";
            this.Invalidate();
        }

        private void OyunBitti()
        {
            _oyunDongusu.Stop();
            _dusmanDogurmaZamanlayici.Stop();
            MessageBox.Show($"Oyun Bitti! Skorunuz: {_skor}");
        }

        private void OyunFormu_Paint(object sender, PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            g.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;

           
            if (_yol.Count > 1)
            {
                g.DrawLines(new Pen(Color.Gray, 40), _yol.ToArray());
                g.DrawLines(new Pen(Color.Yellow, 2), _yol.ToArray());
            }

            
            foreach (var kule in _kuleler)
            {
               
                using (Pen menzilPen = new Pen(Color.FromArgb(100, 200, 200, 200), 2))
                {
                    menzilPen.DashStyle = System.Drawing.Drawing2D.DashStyle.Dash;
                    g.DrawEllipse(menzilPen,
                        kule.Konum.X - kule.Menzil,
                        kule.Konum.Y - kule.Menzil,
                        kule.Menzil * 2,
                        kule.Menzil * 2);
                }

               
                Brush firca = new SolidBrush(kule.Renk);
                g.FillRectangle(firca, kule.Konum.X - 15, kule.Konum.Y - 15, 30, 30);
                g.DrawRectangle(Pens.White, kule.Konum.X - 15, kule.Konum.Y - 15, 30, 30);

                
                kule.Saldir(_dusmanlar, g);
            }

          
            foreach (var d in _dusmanlar)
            {
                g.FillEllipse(Brushes.DarkGreen, d.Konum.X - 10, d.Konum.Y - 10, 20, 20);

                
                float canYuzdesi = (float)d.Can / d.MaxCan;
                g.FillRectangle(Brushes.Red, d.Konum.X - 10, d.Konum.Y - 18, 20, 4);
                g.FillRectangle(Brushes.Lime, d.Konum.X - 10, d.Konum.Y - 18, 20 * canYuzdesi, 4);
            }
        }

        private void OyunFormu_MouseClick(object sender, MouseEventArgs e)
        {
            if (e.Y < 60 || e.Y > this.Height - 80) return;

            Kule yeniKule = null;

            if (_seciliKuleTipi == "Ok" && _altin >= 100)
                yeniKule = new OkKulesi(e.Location);
            else if (_seciliKuleTipi == "Top" && _altin >= 250)
                yeniKule = new TopKulesi(e.Location);
            else if (_seciliKuleTipi == "Buyu" && _altin >= 200)
                yeniKule = new BuyuKulesi(e.Location);

            if (yeniKule != null)
            {
                _kuleler.Add(yeniKule);
                _altin -= yeniKule.Fiyat;
            }
        }
    }
}